create table profiles(id uuid primary key references auth.users on delete cascade, nama text, role text not null default 'siswa' check (role in ('siswa','guru')), created_at timestamptz default now());
create table modules(id serial primary key, kelas text not null, judul text unique not null, deskripsi text);
create table videos(id serial primary key, module_id int references modules on delete cascade, subbab text, judul text, url text, kanal text, verified boolean default false);
create table progress(user_id uuid references auth.users on delete cascade, module_id int references modules on delete cascade, done boolean default false, primary key(user_id,module_id));
create table ai_documents(id serial primary key, owner uuid references auth.users on delete cascade default auth.uid(), jenis text, judul text, isi text, created_at timestamptz default now());
create or replace function is_guru() returns boolean language sql security definer set search_path=public as $$ select exists(select 1 from profiles where id=auth.uid() and role='guru') $$;
-- Semua akun baru SELALU 'siswa'. Peran guru hanya diberikan admin (lihat README).
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into profiles(id,nama) values(new.id,new.raw_user_meta_data->>'nama'); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();
alter table profiles enable row level security; alter table modules enable row level security; alter table videos enable row level security; alter table progress enable row level security; alter table ai_documents enable row level security;
create policy "baca profil sendiri" on profiles for select using (id=auth.uid() or is_guru());
create policy "baca modul" on modules for select using (auth.uid() is not null);
create policy "guru kelola modul" on modules for all using (is_guru()) with check (is_guru());
create policy "baca video" on videos for select using (auth.uid() is not null);
create policy "guru kelola video" on videos for all using (is_guru()) with check (is_guru());
create policy "progres sendiri" on progress for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "guru lihat progres" on progress for select using (is_guru());
create policy "dokumen guru" on ai_documents for all using (owner=auth.uid() and is_guru()) with check (owner=auth.uid() and is_guru());
insert into modules(kelas,judul,deskripsi) values
('X','Persamaan Dasar Akuntansi','Aset, liabilitas, ekuitas, pengaruh transaksi, dan analisis transaksi.'),
('X','Etika Profesi dan Kode Etik Ikatan Akuntan Indonesia (IAI)','Prinsip etika, integritas, objektivitas, kompetensi, kerahasiaan, dan studi kasus.'),
('X','Pengenalan Jurnal Umum','Akun, saldo normal, debit-kredit, bukti transaksi, format jurnal.'),
('X','Dokumentasi Transaksi','Jenis dan fungsi bukti transaksi, pemeriksaan, pengarsipan.'),
('XI','Praktikum Akuntansi Perusahaan Jasa','Siklus akuntansi: jurnal, buku besar, neraca saldo, penyesuaian, laporan, penutupan.'),
('XI','Praktikum Akuntansi Perusahaan Dagang','Pembelian, penjualan, retur, potongan, persediaan, HPP, laporan keuangan.'),
('XII','Praktikum Akuntansi Perusahaan Manufaktur','Bahan baku, tenaga kerja langsung, overhead, harga pokok produksi.'),
('XII','Akuntansi Lembaga','Karakteristik lembaga, transaksi, pencatatan, pelaporan, studi kasus.'),
('XII','Perpajakan','Konsep pajak, perhitungan contoh, administrasi (rujuk sumber resmi DJP).'),
('XII','Spreadsheet dan Laboratorium Akuntansi','Formula, referensi sel, fungsi logika/statistik, rekonsiliasi, laporan.');
