'use client';
import {useEffect,useState} from 'react';import {useRouter} from 'next/navigation';import {sb} from '../../lib/supabase';
async function ai(mode,messages){const {data:{session}}=await sb.auth.getSession();
 const r=await fetch('/api/ai',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+session.access_token},body:JSON.stringify({mode,messages})});
 const d=await r.json();if(!r.ok)throw new Error(d.error);return d.text}
function Tutor(){const [m,setM]=useState([]);const [t,setT]=useState('');const [b,setB]=useState(false);const [e,setE]=useState('');
 async function send(){if(!t.trim())return;const n=[...m,{role:'user',content:t}];setM(n);setT('');setB(true);setE('');
  try{setM([...n,{role:'assistant',content:await ai('tutor',n)}])}catch(x){setE(x.message)}setB(false)}
 return <div><h2>AI Nova Tutor</h2>{m.length===0&&<p>Belum ada percakapan. Tanyakan apa saja tentang akuntansi.</p>}{m.map((x,i)=><div key={i} className={'msg '+(x.role==='user'?'u':'a')}>{x.content}</div>)}{b&&<p>Nova sedang berpikir...</p>}{e&&<p className="err">{e}</p>}
 <textarea rows={3} value={t} onChange={x=>setT(x.target.value)} placeholder="Tulis pertanyaan..."/><button className="btn" disabled={b} onClick={send}>Kirim</button></div>}
function Studio(){const [f,setF]=useState({jenis:'Modul Ajar',kelas:'X',topik:'',tujuan:'',durasi:'2 x 45 menit',jumlah:'10'});const [o,setO]=useState('');const [b,setB]=useState(false);const [e,setE]=useState('');const [s,setS]=useState('');
 const set=k=>x=>setF({...f,[k]:x.target.value});
 async function gen(){if(!f.topik.trim())return setE('Topik wajib diisi.');setB(true);setE('');setS('');
  try{setO(await ai('studio',[{role:'user',content:`Buat ${f.jenis} Kurikulum Merdeka, SMK AKL Kelas ${f.kelas}. Topik: ${f.topik}. Tujuan: ${f.tujuan||'(rumuskan)'}. Durasi: ${f.durasi}. Jumlah soal (jika relevan): ${f.jumlah}.`}]))}catch(x){setE(x.message)}setB(false)}
 async function save(){const {error}=await sb.from('ai_documents').insert({jenis:f.jenis,judul:f.topik,isi:o});setS(error?error.message:'Tersimpan.')}
 function dl(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([o],{type:'text/markdown'}));a.download=f.jenis+'.md';a.click()}
 return <div><h2>AI Content Studio</h2><div className="card"><select value={f.jenis} onChange={set('jenis')}>{['Modul Ajar','RPP','ATP','LKPD','Bahan Ajar','Bank Soal','Kisi-kisi Asesmen','Rubrik Penilaian','Kunci Jawaban dan Pembahasan'].map(x=><option key={x}>{x}</option>)}</select>
 <select value={f.kelas} onChange={set('kelas')}><option>X</option><option>XI</option><option>XII</option></select><input placeholder="Topik" value={f.topik} onChange={set('topik')}/><input placeholder="Tujuan pembelajaran" value={f.tujuan} onChange={set('tujuan')}/><input placeholder="Durasi" value={f.durasi} onChange={set('durasi')}/><input placeholder="Jumlah soal" value={f.jumlah} onChange={set('jumlah')}/>
 <button className="btn" disabled={b} onClick={gen}>{b?'Membuat...':'Buat Dokumen'}</button>{e&&<p className="err">{e}</p>}</div>
 {o&&<div className="card" style={{marginTop:16}}><textarea rows={20} value={o} onChange={x=>setO(x.target.value)}/><button className="btn" onClick={save}>Simpan</button> <button className="btn" onClick={dl}>Unduh .md</button> {s}</div>}</div>}
function Mapel({user}){const [mods,setMods]=useState(null);const [done,setDone]=useState({});const [k,setK]=useState('Semua');const [e,setE]=useState('');
 useEffect(()=>{(async()=>{const a=await sb.from('modules').select('*').order('id');if(a.error)return setE(a.error.message);setMods(a.data);const p=await sb.from('progress').select('module_id,done').eq('user_id',user.id);setDone(Object.fromEntries((p.data||[]).map(x=>[x.module_id,x.done])))})()},[]);
 async function toggle(id){const v=!done[id];setDone({...done,[id]:v});await sb.from('progress').upsert({user_id:user.id,module_id:id,done:v})}
 if(e)return <p className="err">{e}</p>;if(!mods)return <p>Memuat...</p>;
 return <div><h2>Mata Pelajaran Kurikulum AKL</h2>{['Semua','X','XI','XII'].map(x=><button key={x} className={'chip '+(k===x?'on':'')} onClick={()=>setK(x)}>{x==='Semua'?'Semua Kelas':'Kelas '+x}</button>)}
 <div className="grid" style={{marginTop:16}}>{mods.filter(m=>k==='Semua'||m.kelas===k).map(m=><div className="card" key={m.id}><small>Kelas {m.kelas}</small><h3>{m.judul}</h3><p>{m.deskripsi}</p><button className="btn" onClick={()=>toggle(m.id)}>{done[m.id]?'✓ Sudah dipelajari':'Tandai dipelajari'}</button></div>)}</div></div>}
export default function Dash(){const r=useRouter();const [u,setU]=useState(null);const [p,setP]=useState(null);const [v,setV]=useState('home');
 useEffect(()=>{(async()=>{const {data:{session}}=await sb.auth.getSession();if(!session)return r.replace('/');setU(session.user);const {data}=await sb.from('profiles').select('*').eq('id',session.user.id).single();setP(data)})()},[]);
 if(!u||!p)return <p style={{padding:24}}>Memuat...</p>;const guru=p.role==='guru';
 const menu=[['home',guru?'Dashboard Guru':'Dashboard Siswa'],['mapel','Mata Pelajaran'],['tutor','AI Nova Tutor'],...(guru?[['studio','AI Content Studio']]:[])];
 return <><aside className="side"><h2>AKUNOVA<br/><small>AI</small></h2>{menu.map(([k,l])=><button key={k} className={v===k?'on':''} onClick={()=>setV(k)}>{l}</button>)}<button onClick={async()=>{await sb.auth.signOut();r.push('/')}}>Keluar</button></aside>
 <main className="main">{v==='home'&&<div><h2>Halo, {p.nama||u.email} ({p.role})</h2><div className="card">Fitur kelas, tugas, kuis, nilai, dan video belum diimplementasikan di versi awal ini. Lihat README.</div></div>}
 {v==='mapel'&&<Mapel user={u}/>}{v==='tutor'&&<Tutor/>}{v==='studio'&&guru&&<Studio/>}</main></>}
