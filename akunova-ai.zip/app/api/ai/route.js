import {createClient} from '@supabase/supabase-js';
const SYS={tutor:'Kamu Nova, tutor akuntansi untuk siswa SMK AKL di Indonesia. Jawab dalam Bahasa Indonesia, bertahap, dengan contoh. Jika tidak yakin (terutama aturan pajak), katakan dan sarankan sumber resmi.',
studio:'Kamu asisten guru SMK AKL di Indonesia. Hasilkan dokumen terstruktur (Markdown) sesuai input guru. Jangan mengarang peraturan; tandai bagian yang perlu diverifikasi guru.'};
export async function POST(req){
 const token=(req.headers.get('authorization')||'').replace('Bearer ','');
 const sb=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,{global:{headers:{Authorization:'Bearer '+token}}});
 const {data:{user}}=await sb.auth.getUser(token);
 if(!user)return Response.json({error:'Belum login.'},{status:401});
 const {mode,messages}=await req.json();
 if(!SYS[mode]||!Array.isArray(messages))return Response.json({error:'Permintaan tidak valid.'},{status:400});
 if(mode==='studio'){const {data:p}=await sb.from('profiles').select('role').eq('id',user.id).single();if(p?.role!=='guru')return Response.json({error:'Khusus Guru.'},{status:403})}
 if(!process.env.ANTHROPIC_API_KEY)return Response.json({error:'ANTHROPIC_API_KEY belum dikonfigurasi.'},{status:503});
 const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':process.env.ANTHROPIC_API_KEY,'anthropic-version':'2023-06-01'},
  body:JSON.stringify({model:'claude-sonnet-4-6',max_tokens:mode==='studio'?4000:1500,system:SYS[mode],messages:messages.slice(-20)})});
 const d=await r.json();if(!r.ok)return Response.json({error:d.error?.message||'Layanan AI gagal.'},{status:502});
 return Response.json({text:d.content.map(c=>c.text||'').join('')});}
