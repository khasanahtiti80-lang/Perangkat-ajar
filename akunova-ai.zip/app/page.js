'use client';
import {useState} from 'react';import {useRouter} from 'next/navigation';import {sb} from '../lib/supabase';
export default function Login(){
 const r=useRouter();const [reg,setReg]=useState(false);const [f,setF]=useState({nama:'',email:'',pw:''});const [err,setErr]=useState('');const [info,setInfo]=useState('');const [busy,setBusy]=useState(false);
 const set=k=>e=>setF({...f,[k]:e.target.value});
 async function go(e){e.preventDefault();setErr('');setInfo('');
  if(!/^\S+@\S+\.\S+$/.test(f.email))return setErr('Email tidak valid.');
  if(f.pw.length<8)return setErr('Kata sandi minimal 8 karakter.');
  if(reg&&!f.nama.trim())return setErr('Nama wajib diisi.');
  setBusy(true);
  const {error}=reg?await sb.auth.signUp({email:f.email,password:f.pw,options:{data:{nama:f.nama}}}):await sb.auth.signInWithPassword({email:f.email,password:f.pw});
  setBusy(false);if(error)return setErr(error.message);
  if(reg)return setInfo('Pendaftaran berhasil. Cek email untuk konfirmasi, lalu masuk. Akun baru berperan Siswa; peran Guru diberikan admin.');
  r.push('/dashboard')}
 async function reset(){if(!f.email)return setErr('Isi email dulu.');const {error}=await sb.auth.resetPasswordForEmail(f.email);if(error)setErr(error.message);else setInfo('Tautan pemulihan dikirim.')}
 return <div className="login card"><h1 style={{margin:0}}>AKUNOVA <span style={{color:'#7aa800'}}>AI</span></h1><p><i>Create Smarter Lessons, Learn Accounting Better.</i></p>
 <form onSubmit={go}>{reg&&<input placeholder="Nama lengkap" value={f.nama} onChange={set('nama')}/>}<input placeholder="Email" value={f.email} onChange={set('email')}/><input type="password" placeholder="Kata sandi" value={f.pw} onChange={set('pw')}/>
 {err&&<p className="err">{err}</p>}{info&&<p>{info}</p>}<button className="btn" disabled={busy} style={{width:'100%'}}>{busy?'Memproses...':reg?'Daftar Sekarang':'Masuk'}</button></form>
 <p><a href="#" onClick={e=>{e.preventDefault();setReg(!reg)}}>{reg?'Sudah punya akun? Masuk':'Belum punya akun? Daftar Sekarang'}</a>{!reg&&<> · <a href="#" onClick={e=>{e.preventDefault();reset()}}>Lupa sandi</a></>}</p></div>}
