import './globals.css';
export const metadata={title:'AKUNOVA AI',description:'Create Smarter Lessons, Learn Accounting Better.'};
export default function L({children}){return <html lang="id"><body>{children}</body></html>}
