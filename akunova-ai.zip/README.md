# AKUNOVA AI (versi awal)
Next.js 14 + Supabase (auth, database, RLS) + Claude API (backend route `/api/ai`).

## Status jujur
Belum diuji (belum pernah di-build). Sudah ada: login/daftar/lupa sandi, dashboard per peran, 10 modul + filter kelas + progres, Nova Tutor, AI Content Studio (guru, simpan + unduh .md), RLS.
Belum ada: materi lengkap per modul, pemutar video, kuis/E-LKPD, kelas & tugas, penilaian, ekspor DOCX/PDF.

## Langkah
1. Buat proyek di supabase.com, buka SQL Editor, jalankan `supabase/schema.sql`.
2. Salin `.env.example` ke `.env.local`, isi URL & anon key (Settings > API) dan `ANTHROPIC_API_KEY`.
3. `npm install && npm run dev`
4. Jadikan akun Guru (hanya admin): `update profiles set role='guru' where id=(select id from auth.users where email='guru@email.com');`
5. Deploy: push ke GitHub, import di vercel.com, isi 3 environment variable yang sama, Deploy.
6. Supabase > Authentication > URL Configuration: isi Site URL dengan domain Vercel.
